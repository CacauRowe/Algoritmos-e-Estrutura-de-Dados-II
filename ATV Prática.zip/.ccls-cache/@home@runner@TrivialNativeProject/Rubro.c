                #include <stdio.h>
                #include <stdlib.h>
                #include <time.h>

                typedef enum { RED, BLACK } Color;

                // Estrutura do nó da árvore Rubro-Negra
                typedef struct RBNode {
                    int key;
                    Color color;
                    struct RBNode* left;
                    struct RBNode* right;
                    struct RBNode* parent;
                } RBNode;

                RBNode* createRBNode(int key) {
                    RBNode* node = (RBNode*)malloc(sizeof(RBNode));
                    node->key = key;
                    node->color = RED;
                    node->left = node->right = node->parent = NULL;
                    return node;
                }

                RBNode* root = NULL;

                void leftRotate(RBNode** root, RBNode* x, int* rotations) {
                    RBNode* y = x->right;
                    x->right = y->left;
                    if (y->left != NULL) y->left->parent = x;
                    y->parent = x->parent;
                    if (x->parent == NULL) *root = y;
                    else if (x == x->parent->left) x->parent->left = y;
                    else x->parent->right = y;
                    y->left = x;
                    x->parent = y;
                    (*rotations)++;
                }

                void rightRotate(RBNode** root, RBNode* y, int* rotations) {
                    RBNode* x = y->left;
                    y->left = x->right;
                    if (x->right != NULL) x->right->parent = y;
                    x->parent = y->parent;
                    if (y->parent == NULL) *root = x;
                    else if (y == y->parent->right) y->parent->right = x;
                    else y->parent->left = x;
                    x->right = y;
                    y->parent = x;
                    (*rotations)++;
                }

                void insertFixUp(RBNode** root, RBNode* z, int* rotations) {
                    while (z->parent != NULL && z->parent->color == RED) {
                        if (z->parent == z->parent->parent->left) {
                            RBNode* y = z->parent->parent->right;
                            if (y != NULL && y->color == RED) {
                                z->parent->color = BLACK;
                                y->color = BLACK;
                                z->parent->parent->color = RED;
                                z = z->parent->parent;
                            } else {
                                if (z == z->parent->right) {
                                    z = z->parent;
                                    leftRotate(root, z, rotations);
                                }
                                z->parent->color = BLACK;
                                z->parent->parent->color = RED;
                                rightRotate(root, z->parent->parent, rotations);
                            }
                        } else {
                            RBNode* y = z->parent->parent->left;
                            if (y != NULL && y->color == RED) {
                                z->parent->color = BLACK;
                                y->color = BLACK;
                                z->parent->parent->color = RED;
                                z = z->parent->parent;
                            } else {
                                if (z == z->parent->left) {
                                    z = z->parent;
                                    rightRotate(root, z, rotations);
                                }
                                z->parent->color = BLACK;
                                z->parent->parent->color = RED;
                                leftRotate(root, z->parent->parent, rotations);
                            }
                        }
                    }
                    (*root)->color = BLACK;
                }

                void insertRB(RBNode** root, int key, int* rotations) {
                    RBNode* z = createRBNode(key);
                    RBNode* y = NULL;
                    RBNode* x = *root;

                    while (x != NULL) {
                        y = x;
                        if (z->key < x->key) {
                            x = x->left;
                        } else {
                            x = x->right;
                        }
                    }

                    z->parent = y;
                    if (y == NULL) {
                        *root = z;
                    } else if (z->key < y->key) {
                        y->left = z;
                    } else {
                        y->right = z;
                    }

                    insertFixUp(root, z, rotations);
                }

                RBNode* deleteFixUp(RBNode** root, RBNode* x, RBNode* xParent, int* rotations) {
                    while (x != *root && (x == NULL || x->color == BLACK)) {
                        if (x == xParent->left) {
                            RBNode* w = xParent->right;
                            if (w->color == RED) {
                                w->color = BLACK;
                                xParent->color = RED;
                                leftRotate(root, xParent, rotations);
                                w = xParent->right;
                            }
                            if ((w->left == NULL || w->left->color == BLACK) && 
                                (w->right == NULL || w->right->color == BLACK)) {
                                w->color = RED;
                                x = xParent;
                                xParent = x->parent;
                            } else {
                                if (w->right == NULL || w->right->color == BLACK) {
                                    if (w->left != NULL) w->left->color = BLACK;
                                    w->color = RED;
                                    rightRotate(root, w, rotations);
                                    w = xParent->right;
                                }
                                w->color = xParent->color;
                                xParent->color = BLACK;
                                if (w->right != NULL) w->right->color = BLACK;
                                leftRotate(root, xParent, rotations);
                                x = *root;
                            }
                        } else {
                            RBNode* w = xParent->left;
                            if (w->color == RED) {
                                w->color = BLACK;
                                xParent->color = RED;
                                rightRotate(root, xParent, rotations);
                                w = xParent->left;
                            }
                            if ((w->left == NULL || w->left->color == BLACK) &&
                                (w->right == NULL || w->right->color == BLACK)) {
                                w->color = RED;
                                x = xParent;
                                xParent = x->parent;
                            } else {
                                if (w->left == NULL || w->left->color == BLACK) {
                                    if (w->right != NULL) w->right->color = BLACK;
                                    w->color = RED;
                                    leftRotate(root, w, rotations);
                                    w = xParent->left;
                                }
                                w->color = xParent->color;
                                xParent->color = BLACK;
                                if (w->left != NULL) w->left->color = BLACK;
                                rightRotate(root, xParent, rotations);
                                x = *root;
                            }
                        }
                    }
                    if (x != NULL) x->color = BLACK;
                    return x;
                }

                RBNode* findRB(RBNode* root, int key) {
                    while (root != NULL && root->key != key) {
                        if (key < root->key) {
                            root = root->left;
                        } else {
                            root = root->right;
                        }
                    }
                    return root;
                }

                RBNode* deleteRB(RBNode** root, int key, int* rotations) {
                    RBNode* z = findRB(*root, key);
                    if (z == NULL) return NULL;

                    RBNode* y = z;
                    RBNode* x;
                    RBNode* xParent = NULL;
                    Color yOriginalColor = y->color;

                    if (z->left == NULL) {
                        x = z->right;
                        if (x != NULL) x->parent = z->parent;
                        if (z->parent == NULL) {
                            *root = x;
                        } else if (z == z->parent->left) {
                            z->parent->left = x;
                        } else {
                            z->parent->right = x;
                        }
                        xParent = z->parent;
                    } else if (z->right == NULL) {
                        x = z->left;
                        if (x != NULL) x->parent = z->parent;
                        if (z->parent == NULL) {
                            *root = x;
                        } else if (z == z->parent->left) {
                            z->parent->left = x;
                        } else {
                            z->parent->right = x;
                        }
                        xParent = z->parent;
                    } else {
                        y = minValueNode(z->right);
                        yOriginalColor = y->color;
                        x = y->right;
                        if (y->parent == z) {
                            if (x != NULL) x->parent = y;
                        } else {
                            if (x != NULL) x->parent = y->parent;
                            y->parent->left = x;
                            y->right = z->right;
                            y->right->parent = y;
                        }
                        if (z->parent == NULL) {
                            *root = y;
                        } else if (z == z->parent->left) {
                            z->parent->left = y;
                        } else {
                            z->parent->right = y;
                        }
                        y->parent = z->parent;
                        y->left = z->left;
                        y->left->parent = y;
                        y->color = z->color;
                    }

                    free(z);

                    if (yOriginalColor == BLACK) {
                        x = deleteFixUp(root, x, xParent, rotations);
                    }

                    return x;
                }